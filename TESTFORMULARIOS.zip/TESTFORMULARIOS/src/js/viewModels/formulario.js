/**
 * @license
 * Copyright (c) 2014, 2024, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
/*
 * Your Formulario ViewModel code goes here
 */
define(['../accUtils', 'knockout', 'ojs/ojformlayout', 'ojs/ojinputtext',
    'ojs/ojbutton', 'ojs/ojradioset', 'ojs/ojlabel', 'ojs/ojdatetimepicker',
    'ojs/ojselectcombobox', 'ojs/ojselectsingle', 'ojs/ojinputnumber', 'ojs/ojvalidator-regexp',
    'ojs/ojswitch', 'ojs/ojdialog', 'ojs/ojvalidationgroup', 'ojs/ojmessages'],
    function (accUtils, ko) {
        function FormularioViewModel() {
            this.nombre = ko.observable('');
            this.apellidoPaterno = ko.observable('');
            this.apellidoMaterno = ko.observable('');
            this.fechaNacimiento = ko.observable('');
            this.genero = ko.observable('Masculino');
            this.carrera = ko.observable('');
            this.anioIngreso = ko.observable(null);
            this.correo = ko.observable('');
            this.contrasena = ko.observable('');
            this.extranjero = ko.observable(false);
            this.observaciones = ko.observable('');

            async function validarCampos() {
                const components = document.querySelectorAll('oj-input-text, oj-input-password, oj-input-number, oj-radioset');
                const invalidComponents = [];

                for (const comp of components) {
                    const isValid = await comp.validate();
                    if (isValid !== 'valid') {
                        invalidComponents.push(comp);
                    }
                }
                return invalidComponents;
            }

            this.registrar = async () => {
                const invalidComponents = await validarCampos();

                if (invalidComponents.length === 0) {
                    const data = {
                        Nombre: this.nombre(),
                        'Apellido Paterno': this.apellidoPaterno(),
                        'Apellido Materno': this.apellidoMaterno(),
                        'Fecha de Nacimiento': this.fechaNacimiento(),
                        Género: this.genero(),
                        Carrera: this.carrera(),
                        'Año de Ingreso': this.anioIngreso(),
                        Correo: this.correo(),
                        Contraseña: this.contrasena(),
                        'Estudiante Extranjero': this.extranjero(),
                        Observaciones: this.observaciones()
                    };

                    document.getElementById('dialogContent').textContent = JSON.stringify(data, null, 2);
                    const dialog = document.getElementById('dialog');
                    dialog.open();
                }
            };

            this.closeDialog = () => {
                const dialog = document.getElementById('dialog');
                dialog.close();
            };

            /**
             * Optional ViewModel method invoked after the View is inserted into the
             * document DOM.  The application can put logic that requires the DOM being
             * attached here.
             * This method might be called multiple times - after the View is created
             * and inserted into the DOM and after the View is reconnected
             * after being disconnected.
             */
            this.connected = () => {
                accUtils.announce('Formulario page loaded.');
                document.title = "Formulario";
            };

            /**
             * Optional ViewModel method invoked after the View is disconnected from the DOM.
             */
            this.disconnected = () => {
                // Implement if needed
            };

            /**
             * Optional ViewModel method invoked after transition to the new View is complete.
             * That includes any possible animation between the old and the new View.
             */
            this.transitionCompleted = () => {
                // Implement if needed
            };
        }

        return FormularioViewModel;
    }
);
