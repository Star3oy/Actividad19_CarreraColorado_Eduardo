import { ButtonsetMultipleWebElementBase } from './ButtonsetMultipleWebElementBase';
/**
 * The component WebElement for [oj-c-buttonset-multiple](../../../oj-c/docs/oj.ButtonsetMultiple.html).
 * Do not instantiate this class directly, instead, use
 * [findButtonsetMultiple](../functions/findButtonsetMultiple.html).
 */
export declare class ButtonsetMultipleWebElement extends ButtonsetMultipleWebElementBase {
}
